clear all
warning off
addpath(genpath(fullfile('utils/')));
addpath(genpath(fullfile('dataset/')));
seed = 0;
rng('default')
rng(seed);




%----------------------parameters setting-------------------

%-----------------method parameters
bits = [8,16,32,64];
nb = numel(bits);

param.bits = bits;
param.maxIter =10;
param.method = 'DCGH';

%-----------------basie information
% dataname = 'mir_cnn';
% param.dataname = dataname;
% alpha =1e4;beta =1e-1;lambda =1e-4;

dataname = 'flickr-25k';
param.dataname = dataname;
alpha =1e4;beta =1e-1;lambda =1e-2;


% dataname = 'wikiData';
% param.dataname = dataname;
% alpha =1e1; beta =1e1; lambda =1e-2;


% dataname = 'iapr-tc12';
% param.dataname = dataname;
% alpha =1e3;beta =1e-2;lambda =1e-3;
% 

% dataname = 'nus-wide-clear';
% param.dataname = dataname;
% alpha =1e4;beta =1e-1;lambda =1e-4;
% 

%parameter search
% alpha =[1e-4,1e-3,1e-2,1e-1];%
% beta =[1e4,1e2,1e3,1e4]; %[1e-4,1e-3,1e-2,1e-1];
% lambda = [1e-4,1e-3,1e-2,1e-1];%




par_1 = numel(alpha);
par_2 = numel(beta);
par_4 = numel(lambda);


%load dataset
dataset = load_data(dataname);
n_anchors = 1500;
rbf2;
total_res=[];
% run algorithm
for i = 1: nb
    for ij=1:par_1
        for jj=1:par_2 
            for jjj=1:par_4
                
                fprintf('...method: %s\n', param.method);
                fprintf('...bit: %d\n', bits(i));
                param.bit = bits(i);
                param.alpha = alpha(ij);
                param.beta= beta(jj);
                param.lambda= lambda(jjj)              
                trainL = dataset.databaseL;
                trainL = normr(trainL);              
                [ImgToTxt,TxtToIm]=LHCC(trainL, param, dataset);
                total_res = [total_res;ImgToTxt,TxtToIm, param.bit, param.alpha, param.beta, param.lambda];
                
            end
        end
    end
end
save([dataname, num2str('_result'),'.mat'], 'total_res');


