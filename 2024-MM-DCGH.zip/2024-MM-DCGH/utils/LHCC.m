function [ImgToTxt,TxtToImg] = LHCC(trainLabel, param, dataset)
seed = 0;
rng('default');
rng(seed);

X1 = dataset.XDatabase;
X2 = dataset.YDatabase;
XTest = dataset.XTest;
YTest = dataset.YTest;
testL = dataset.testL;
databaseL = dataset.databaseL;

top_K=1000;
[d1,~] = size(X1');
[d2,~] = size(X2');

bit = param.bit;
maxIter = param.maxIter;

lambda = param.lambda;
beta = param.beta;
alpha = param.alpha;

numTrain = size(trainLabel, 1);
c = size(trainLabel,2);


%--------------------------------initial------------------------------------
H= ones(bit,numTrain);
H=sgn(H);



W1=randn(bit,d1);
W2=randn(bit,d2);
U=randn(bit,c);
V1=randn(c,numTrain);V2=V1;
F=randn(c,numTrain);


tic
for epoch = 1:maxIter
    %% for test instance
    %    Bold =H
    %--------- B-step
    B1_tmp=(W1*X1'+alpha*U*V1+beta*bit*H*trainLabel*trainLabel');
    B1=constraint(B1_tmp,bit,numTrain)';
    B2_tmp=(W2*X2'+alpha*U*V2+beta*bit*H*trainLabel*trainLabel');
    B2=constraint(B2_tmp,bit,numTrain)';
    %--------- H-step
    H=sgn(beta*bit*(B1*trainLabel*trainLabel'+B2*trainLabel*trainLabel')+alpha*U*F);
    %--------- W-step
    [W11,~,SW1] = svd(B1*X1,'econ');
    W1 = W11*SW1';
    [W22,~,SW2] = svd(B2*X2,'econ');
    W2 = W22*SW2';
    %--------- U-step
    [U1,~,SU] = svd(B1*V1'+B2*V2'+alpha*H*F','econ');
    U = U1*SU';
    %--------- V-step
    [V11,~,SV1] = svd(U'*B1,'econ');
    V1 = V11*SV1';
    
    [V22,~,SV2] = svd(U'*B2,'econ');
    V2 = V22*SV2';
    
    %--------- F-step
    [F1,~,SF] = svd(U'*H,'econ');
    F = F1*SF';
    
    
    
    
    
    %--------- B-step
    %     obj(epoch) = norm(H-Bold,'fro')^2/norm(Bold,'fro')^2;
    %     if epoch > 2
    %         %if  obj(iter)< 10^-2 || abs(obj(iter)-obj(iter-1)) < 10^-3
    %         if obj(epoch) < 10^-3
    %             break
    %         end
    %     end
    
    
    
    %     epoch = epoch + 1;


    
    
    
    
    
    
    
    
end

toc

    %-----------------real-time evaluation----------------------------
    P1=H*X1/(X1'*X1+lambda*eye(d1));
    P2=H*X2/(X2'*X2+lambda*eye(d2));
    tBX = sign(P1*XTest')';
    tBY = sign(P2*YTest')';
    HH=H';HH(HH<0) = 0;
    ti_H = compactbit(HH);
    tBX(tBX<0) = 0;
    tBX = compactbit(tBX);
    tBY(tBY<0) = 0;
    tBY = compactbit(tBY);
    Dhamm = hammingDist(tBX, ti_H);
    [~, HammingRank]=sort(Dhamm,2);
    out.MAP_test(1) = cal_mAP(databaseL,testL,HammingRank);
    [out.Image_VS_Text_precision, out.Image_VS_Text_recall] = precision_recall(HammingRank',databaseL,testL);
    out.Image_To_Text_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
    Dhamm = hammingDist(tBY, ti_H);
    [~, HammingRank]=sort(Dhamm,2);
    out.MAP_test(2) = cal_mAP(databaseL,testL,HammingRank);
    [out.Text_VS_Image_precision, out.Text_VS_Image_recall] = precision_recall(HammingRank', databaseL,testL);
    out.Text_To_Image_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
    ImgToTxt=out.MAP_test(1);
    TxtToImg=out.MAP_test(2);
    fprintf('...iter:%d,   i2t:%.4f,   t2i:%.4f\n',epoch, ImgToTxt, TxtToImg)
 
    i2t_pre=out.Image_VS_Text_precision;
    i2t_rec=out.Image_VS_Text_recall;
    i2t_pre_top=out.Image_To_Text_Precision;
    t2i_pre=out.Text_VS_Image_precision;
    t2i_rec=out.Text_VS_Image_recall;
    t2i_pre_top=out.Text_To_Image_Precision;
    
    save('DCGH_wiki.mat', 'i2t_pre', 'i2t_rec', 'i2t_pre_top', 't2i_pre', 't2i_rec', 't2i_pre_top');

end




