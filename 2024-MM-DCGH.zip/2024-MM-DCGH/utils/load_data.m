function dataset = load_data(dataname)
switch dataname
     case 'wikiData'
        load dataset/wikiData.mat I_te I_tr T_te T_tr L_te L_tr;
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr;
        dataset.YDatabase = T_tr;
        dataset.testL = L_te;
        dataset.databaseL = L_tr;
     case 'wiki-partial'
        load dataset/wiki-partial.mat I_te I_tr T_te T_tr L_te L_tr;
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr;
        dataset.YDatabase = T_tr;
        dataset.testL = L_te;
        dataset.databaseL = L_tr;
     case 'wiki-unpaired'
        load dataset/wiki-unpaired.mat I_te I_tr T_te T_tr L_te L_tr;
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr;
        dataset.YDatabase = T_tr;
        dataset.testL = L_te;
        dataset.databaseL = L_tr;       
    case 'nus-vgg'
        load ./data/mynus_cnn.mat I_te I_tr T_te T_tr L_te L_tr;
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr;
        dataset.YDatabase = T_tr;
        dataset.testL = L_te;
        dataset.databaseL = L_tr;
    case 'mir_cnn'
        load ./dataset/mir_cnn.mat I_te I_tr T_te T_tr L_te L_tr;
        dataset.XTest = I_te;
        dataset.YTest = T_te;
        dataset.XDatabase = I_tr;
        dataset.YDatabase = T_tr;
        dataset.testL = L_te;
        dataset.databaseL = L_tr;
    case 'flickr-25k'
        load dataset/flickr-25k.mat XTest YTest XDatabase YDatabase testL databaseL;
       
        dataset.XTest = XTest;
        dataset.YTest = YTest;
        dataset.XDatabase = XDatabase;
        dataset.YDatabase = YDatabase;
        dataset.testL = testL;
        dataset.databaseL = databaseL;
    case 'flickr-25k-vgg'
        load dataset/flickr-25k.mat VTest YTest VDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),10000);
        dataset.XTest = VTest;
        dataset.YTest = YTest;
        dataset.XDatabase = VDatabase(inx,:);
        dataset.YDatabase = YDatabase(inx,:);
        dataset.testL = testL;
        dataset.databaseL = databaseL(inx,:);
    case 'iapr-tc12'
        load dataset/iapr-tc12.mat XTest YTest XDatabase YDatabase testL databaseL;
        
        dataset.XTest = XTest;
        dataset.YTest = YTest;
        dataset.XDatabase = XDatabase;
        dataset.YDatabase = YDatabase;
        dataset.testL = testL;
        dataset.databaseL = databaseL;
    case 'iapr-tc12-vgg'
        load data/iapr-tc12.mat VTest YTest VDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),10000);
        dataset.XTest = VTest;
        dataset.YTest = YTest;
        dataset.XDatabase = VDatabase;
        dataset.YDatabase = YDatabase;
        dataset.testL = testL;
        dataset.databaseL = databaseL;
    case 'nus-wide-clear'
        load dataset/nus-wide-clear.mat XTest YTest XDatabase YDatabase testL databaseL;
%         inx = randperm(size(databaseL,1),3000);
%         dataset.XTest = XTest;
%         dataset.YTest = YTest;
%         dataset.XDatabase = XDatabase(inx,:);
%         dataset.YDatabase = YDatabase(inx,:);
%         dataset.testL = testL;
%         dataset.databaseL = databaseL(inx,:);
   
        dataset.XTest = XTest;
        dataset.YTest = YTest;
        dataset.XDatabase = XDatabase;
        dataset.YDatabase = YDatabase;
        dataset.testL = testL;
        dataset.databaseL = databaseL;
    case 'nus-wide-tc10-vgg'
        load ./data/nus-wide.mat VTest YTest VDatabase YDatabase testL databaseL;
        inx = randperm(size(databaseL,1),15000);
        dataset.XTest = VTest;
        dataset.YTest = YTest;
        dataset.XDatabase = VDatabase(inx,:);
        dataset.YDatabase = YDatabase(inx,:);
        dataset.testL = testL;
        dataset.databaseL = databaseL(inx,:);
end
end

