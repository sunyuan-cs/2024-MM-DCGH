function [adj] = fixed_Full(nNodes)
adj = ones(nNodes) - eye(nNodes);

